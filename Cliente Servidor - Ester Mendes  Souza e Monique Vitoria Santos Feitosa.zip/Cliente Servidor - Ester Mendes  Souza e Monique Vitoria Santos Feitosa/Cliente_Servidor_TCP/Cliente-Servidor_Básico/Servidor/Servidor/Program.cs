﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace Servidor
{

    class Program
    {

        public static void StartServer()
        {
            
            IPHostEntry host = Dns.GetHostEntry("localhost");
            IPAddress ipAddress = host.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);


            try
            {

                // criando o socket      
                Socket listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                listener.Bind(localEndPoint);  
                listener.Listen(10);

                Console.WriteLine("Aguardando Conexão ...");
                Socket handler = listener.Accept();

                // Incoming data from the client.    
                string data = null;
                byte[] receber_funcao = new byte[100];
                int array_size = 0;

                array_size = handler.Receive(receber_funcao, 0, receber_funcao.Length, 0);
                Array.Resize(ref receber_funcao, array_size);
                data = Encoding.Default.GetString(receber_funcao);
                
                do
                {

                }
                Console.WriteLine("Texto recebido : {0}", data);
                byte[] msg = Encoding.ASCII.GetBytes(data);
                handler.Send(msg);


                handler.Shutdown(SocketShutdown.Both);
                handler.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            
        }


        static void Main(string[] args)
        {
            Console.WriteLine("Testando o Servidor.\n\n");
            StartServer();
        }
    }
}
